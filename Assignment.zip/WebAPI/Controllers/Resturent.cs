﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Repository;
using WebAPI.Utility;

namespace WebAPI.Controllers
{
    //[ApiController]
    //[Route("[controller]")]

    [Produces("application/json")]
    [Route("api/Resturent")]
    public class Resturent : ControllerBase
    {
        private readonly IOptions<MySettingsModel> appSettings;

        private readonly ILogger<Resturent> _logger;

        public Resturent(ILogger<Resturent> logger, IOptions<MySettingsModel> setting)
        {
            appSettings = setting;
            _logger = logger;
        }

        /// <summary>
        /// Create a new order
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateOrder")]
        public IActionResult CreateOrder(Order model)
        {
            var msg = new Message();
            var data = DbClientFactory<OrderDbClient>.Instance.CreateOrder(model, appSettings.Value.DbConn);
            if (data == "C200")
            {    
                msg.IsSuccess = true;
                msg.ReturnMessage = "Order created successfully";               
            }
            else if (data == "C201")
            {
                msg.IsSuccess = false;
                msg.ReturnMessage = "Order already exists";
            }
            //else if (data == "C202")
            //{
            //    msg.IsSuccess = false;
            //    msg.ReturnMessage = "Another message";
            //}
            return Ok(msg);
        }



        /// <summary>
        /// Get all the existing orders list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllOrders")]
        public IActionResult GetOrderItems()
        {
            var data = DbClientFactory<OrderDbClient>.Instance.GetAllOrderItems(appSettings.Value.DbConn);

            return Ok(data);
        }


        [HttpGet]
        [Route("GetOrdersInQue")]
        public IActionResult GetOrderItemsInque()
        {
            var data = DbClientFactory<OrderDbClient>.Instance.GetAllOrderItems(appSettings.Value.DbConn);

            //Filter all orders based on order status
            var inqueueOrders = from s in data where s.OrderStatus == 1 || s.OrderStatus == 2 select s;

            return Ok(inqueueOrders);
        }


        /// <summary>
        /// Get All Orders by order status
        /// </summary>
        /// <param name="orderStat"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllOrders/{orderStat}")]
        public IActionResult GetOrderItemsForStatus(int orderStat)
        {
            var data = DbClientFactory<OrderDbClient>.Instance.GetAllOrderItems(appSettings.Value.DbConn);

            //Filter all orders based on order status
            var inqueueOrders = data.FindAll(x => x.OrderStatus == orderStat);

            return Ok(inqueueOrders);
        }


        /// <summary>
        /// Get All menu Items available
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllMenuItems")]
        public IActionResult GetMenuItems()
        {
            var data = DbClientFactory<MenuItemDbClient>.Instance.GetAllMenuItems(appSettings.Value.DbConn);
            return Ok(data);
        }


        /// <summary>
        /// Make order state (In Queue/Preparing/Order Ready/Picked Up/Cancelled)
        /// </summary>
        /// <param name="orderRef">Order Reference</param>
        /// <param name="status">Order status want to update (1 -In Queue /2 -Preparing / 3-Order Ready / 4-Picked Up / 5-Cancelled)</param>
        /// <returns></returns>
        [HttpGet]
        [Route("ChangeOrderStat/{orderRef}/{status}")]
        public IActionResult StartPreparingOrder(string orderRef, int status)
        {
            var msg = new Message();
            var data = DbClientFactory<OrderDbClient>.Instance.UpdateOrderStatus(orderRef, status, appSettings.Value.DbConn);
            if (data == "U200")
            {
                msg.IsSuccess = true;
                msg.ReturnMessage = "Order updated successfully";
            }
            else if (data == "U201")
            {
                msg.IsSuccess = false;
                msg.ReturnMessage = "Order not exists";
            }
            //else if (data == "C202")
            //{
            //    msg.IsSuccess = false;
            //    msg.ReturnMessage = "Another message";
            //}
            return Ok(msg);
        }
    }
}
