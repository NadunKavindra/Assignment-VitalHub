﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class OrderMenuItem
    {
        public string OrderReference { get; set; }
        public string MenuItemCode { get; set; }
        public string MenuItemDescription { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
    }
}
