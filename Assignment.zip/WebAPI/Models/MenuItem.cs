﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    [DataContract]
    public class MenuItem
    {
        [DataMember(Name = "Id")]
        public int Id { get; set; }

        [DataMember(Name = "Item Code")]
        public string ItemCode { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }

        [DataMember(Name = "Portion Size")]
        public string PortionSize { get; set; }

        [DataMember(Name = "Price")]
        public decimal Price { get; set; }
    }
}
