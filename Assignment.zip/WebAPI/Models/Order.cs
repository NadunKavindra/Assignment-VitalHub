﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI
{
    public class Order
    {
        [DataMember(Name = "Id")]
        public int Id { get; set; }

        [DataMember(Name = "Order Reference")]
        public string OrderReference { get; set; }

        [DataMember(Name = "Order Date And Time")]
        public DateTime OrderDateTime { get; set; }


        [DataMember(Name = "Order Through")]
        public int OrderThrough { get; set; }

        [DataMember(Name = "Order Type")]
        public int OrderType { get; set; }

        [DataMember(Name = "Order Status")]
        public int OrderStatus { get; set; }

        public List<OrderMenuItem> OrderMenuItems { get; set; }
    }
}
