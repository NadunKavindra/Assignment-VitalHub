﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Translators;
using WebAPI.Utility;

namespace WebAPI.Repository
{
    public class MenuItemDbClient
    {
        public List<MenuItem> GetAllMenuItems(string connString)
        {
            return SqlHelper.ExtecuteProcedureReturnData<List<MenuItem>>(connString,
                "GetMenuItems", r => r.TranslateAsMenuItemList());
        }
    }
}
