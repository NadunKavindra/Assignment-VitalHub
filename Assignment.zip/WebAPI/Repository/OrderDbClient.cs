﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Translators;
using WebAPI.Utility;

namespace WebAPI.Repository
{
    public class OrderDbClient
    {
        /// <summary>
        /// Return All the Order Items details in table
        /// </summary>
        /// <param name="connString"></param>
        /// <returns></returns>
        public List<Order> GetAllOrderItems(string connString)
        {
            return SqlHelper.ExtecuteProcedureReturnData<List<Order>>(connString,
                "GetOrderDetails", r => r.TranslateAsOrderItemList());
        }


        /// <summary>
        /// Return All Menu items assigned for paticular order
        /// </summary>
        /// <param name="orderRef"></param>
        /// <param name="connString"></param>
        /// <returns></returns>
        public List<OrderMenuItem> GetAllMenuItemsForAnOrder(string orderRef, string connString)
        {
            SqlParameter[] param = {
                new SqlParameter("@OrderRef",orderRef)
            };
            return SqlHelper.ExtecuteProcedureReturnData<List<OrderMenuItem>>(connString,
                "GetMenuItemsForOrder", r => r.TranslateAsOrderMenuItemList());
        }


        /// <summary>
        /// Create New Order in Order table
        /// </summary>
        /// <param name="model"></param>
        /// <param name="connString"></param>
        /// <returns></returns>
        public string CreateOrder(Order model, string connString)
        {
            var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@Id",model.Id),
                new SqlParameter("@OrderRef",model.OrderReference),
                new SqlParameter("@OrderThrough",model.OrderThrough),
                new SqlParameter("@OrderTyp",model.OrderType),
                new SqlParameter("@OrderStat",model.OrderStatus),
                outParam
            };
            SqlHelper.ExecuteProcedureReturnString(connString, "CreateOrder", param);
            return (string)outParam.Value;
        }


        /// <summary>
        /// Update the order status for related order
        /// </summary>
        /// <param name="orderRef"></param>
        /// <param name="orderState"></param>
        /// <param name="connString"></param>
        /// <returns></returns>
        public string UpdateOrderStatus(string orderRef, int orderState, string connString)
        {
            var outParam = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@OrderRef",orderRef),
                new SqlParameter("@OrderStatus",orderState),
                outParam
            };
            SqlHelper.ExecuteProcedureReturnString(connString, "UpdateOrderStatus", param);
            return (string)outParam.Value;
        }
    }
}
