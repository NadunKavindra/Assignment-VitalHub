﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Utility;

namespace WebAPI.Translators
{
    public static class OrderMenuItemTranslator
    {
        public static OrderMenuItem TranslateAsOrderMenuItem(this SqlDataReader reader, bool isList = false)
        {
            if (!isList)
            {
                if (!reader.HasRows)
                    return null;
                reader.Read();
            }
            var item = new OrderMenuItem();

            if (reader.IsColumnExists("OrderReference"))
                item.OrderReference = SqlHelper.GetNullableString(reader, "OrderReference");

            if (reader.IsColumnExists("MenuItemCode"))
                item.MenuItemCode = SqlHelper.GetNullableString(reader, "MenuItemCode");

            if (reader.IsColumnExists("MenuItemDescription"))
                item.MenuItemDescription = SqlHelper.GetNullableString(reader, "MenuItemDescription");

            if (reader.IsColumnExists("Price"))
                item.UnitPrice = Convert.ToDecimal(SqlHelper.GetNullableString(reader, "Price"));

            if (reader.IsColumnExists("Quantity"))
                item.Quantity = Convert.ToInt32(SqlHelper.GetNullableString(reader, "Quantity"));

            return item;
        }

        public static List<OrderMenuItem> TranslateAsOrderMenuItemList(this SqlDataReader reader)
        {
            var list = new List<OrderMenuItem>();
            while (reader.Read())
            {
                list.Add(TranslateAsOrderMenuItem(reader, true));
            }
            return list;
        }
    }
}
