﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Utility;

namespace WebAPI.Translators
{
    public static class OrderTranslator
    {
        private static readonly IOptions<MySettingsModel> appSettings;
        public static Order TranslateAsOrderItem(this SqlDataReader reader, bool isList = false)
        {
            if (!isList)
            {
                if (!reader.HasRows)
                    return null;
                reader.Read();
            }
            var item = new Order();
            if (reader.IsColumnExists("Int_Key"))
                item.Id = SqlHelper.GetNullableInt32(reader, "Int_Key");

            if (reader.IsColumnExists("OrderReference"))
            {
                item.OrderReference = SqlHelper.GetNullableString(reader, "OrderReference");
                SqlParameter[] param = { new SqlParameter("@OrderRef", item.OrderReference) };
                item.OrderMenuItems = SqlHelper.ExtecuteProcedureReturnData<List<OrderMenuItem>>("Data Source=NADUN-PC;Initial Catalog=ChinaDragon; Integrated Security=true",
                    "GetMenuItemsForOrder", r => r.TranslateAsOrderMenuItemList(), param);
            }
                

            if (reader.IsColumnExists("OrderDateTime"))
                item.OrderDateTime = Convert.ToDateTime(SqlHelper.GetNullableString(reader, "OrderDateTime"));

            if (reader.IsColumnExists("OrderThrough"))
                item.OrderThrough = Convert.ToInt32(SqlHelper.GetNullableString(reader, "OrderThrough"));

            if (reader.IsColumnExists("OrderType"))
                item.OrderType = Convert.ToInt32(SqlHelper.GetNullableString(reader, "OrderType"));

            if (reader.IsColumnExists("OrderStatus"))
                item.OrderStatus = Convert.ToInt32(SqlHelper.GetNullableString(reader, "OrderStatus"));

            return item;
        }


        public static List<Order> TranslateAsOrderItemList(this SqlDataReader reader)
        {
            var list = new List<Order>();
            while (reader.Read())
            {
                list.Add(TranslateAsOrderItem(reader, true));
            }
            return list;
        }
    }
}
