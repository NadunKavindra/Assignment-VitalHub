﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using WebAPI.Utility;

namespace WebAPI.Translators
{
    public static class MenuItemTranslator
    {

        public static MenuItem TranslateAsMenuItem(this SqlDataReader reader, bool isList = false)
        {
            if (!isList)
            {
                if (!reader.HasRows)
                    return null;
                reader.Read();
            }
            var item = new MenuItem();
            if (reader.IsColumnExists("Int_Key"))
                item.Id = SqlHelper.GetNullableInt32(reader, "Int_Key");

            if (reader.IsColumnExists("ItemCode"))
                item.ItemCode = SqlHelper.GetNullableString(reader, "ItemCode");

            if (reader.IsColumnExists("Description"))
                item.Description = SqlHelper.GetNullableString(reader, "Description");

            if (reader.IsColumnExists("PortionSize"))
                item.PortionSize = SqlHelper.GetNullableString(reader, "PortionSize");

            if (reader.IsColumnExists("Price"))
                item.Price = Convert.ToDecimal(SqlHelper.GetNullableString(reader, "Price"));

            return item;
        }

        public static List<MenuItem> TranslateAsMenuItemList(this SqlDataReader reader)
        {
            var list = new List<MenuItem>();
            while (reader.Read())
            {
                list.Add(TranslateAsMenuItem(reader, true));
            }
            return list;
        }
    }
}
