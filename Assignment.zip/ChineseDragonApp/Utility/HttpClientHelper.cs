﻿using Microsoft.Extensions.Options;
using ResturentApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace ResturentApp.Utility
{
    public static class HttpClientHelper
    {

        /// <summary>
        /// Sending request to find web api REST service resource using HttpClient and return responce
        /// </summary>
        /// <param name="requestUri"></param>
        /// <returns>HttpResponseMessage</returns>
        public static async Task<HttpResponseMessage> HttpGetAsyncHelper(string Baseurl, string requestUri)
        {
            using (var client = new HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //Sending request to find web api REST service resource using HttpClient
                HttpResponseMessage Res = await client.GetAsync(requestUri);

                return Res;
            }
        }
    }
}
