﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using ResturentApp.Models;
using ResturentApp.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ChineseDragonApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IOptions<MySettingsModel> appSettings;

        private readonly ILogger<HomeController> _logger;

        //Hosted web API REST Service base url
        //appSettings.Value.Baseurl;
        public HomeController(ILogger<HomeController> logger, IOptions<MySettingsModel> setting)
        {
            appSettings = setting;
            _logger = logger;
        }


       
        /// <summary>
        /// List Down all the In queue orders / preparing Orders
        /// </summary>
        /// <returns></returns>
        public async Task<ActionResult> Inqueue()
        {
            List<OrderViewModel> OrdersInqueue = new List<OrderViewModel>();
            HttpResponseMessage responce = await HttpClientHelper.HttpGetAsyncHelper(appSettings.Value.Baseurl,"GetOrdersInQue");

            if (responce.IsSuccessStatusCode)
            {
                //Storing the response details recieved from web api
                var OrderResponse = responce.Content.ReadAsStringAsync().Result;
                //Deserializing the response recieved from web api and storing into the list
                OrdersInqueue = JsonConvert.DeserializeObject<List<OrderViewModel>>(OrderResponse);
            }
            //returning the list to view
            return View(OrdersInqueue);
        }


        /// <summary>
        /// Update the order, to relavent status (1-In queue /2 -Preparing / 3-Order ready / 4-Picked up / 5-Cancelled)
        /// </summary>
        /// <param name="orderRef"></param>
        /// <param name="orderStat"></param>
        /// <returns></returns>
        public async Task<ActionResult> UpdateOrder(string orderRef, int orderStat)
        {

            HttpResponseMessage responce = await HttpClientHelper.HttpGetAsyncHelper(appSettings.Value.Baseurl, "ChangeOrderStat/" + orderRef + "/" + orderStat.ToString());

            if (responce.IsSuccessStatusCode)
            {
                var UpdateResponse = responce.Content.ReadAsStringAsync().Result;
                Message responceMsg = JsonConvert.DeserializeObject<Message>(UpdateResponse);

                if (!responceMsg.IsSuccess)
                {
                    return View("ErrorPage");
                }
                else
                {
                    List<OrderViewModel> OrdersInqueue = new List<OrderViewModel>();
                    HttpResponseMessage ordersRes = await HttpClientHelper.HttpGetAsyncHelper(appSettings.Value.Baseurl,"GetOrdersInQue");

                    if (ordersRes.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api
                        var OrderResponse = ordersRes.Content.ReadAsStringAsync().Result;
                        //Deserializing the response recieved from web api and storing into the list
                        OrdersInqueue = JsonConvert.DeserializeObject<List<OrderViewModel>>(OrderResponse);

                        return View("Inqueue", OrdersInqueue);
                    }
                    else
                    {
                        return View("ErrorPage");
                    }
                }
            }
            else
            {
                return View("ErrorPage");
            }
           
        }




        /// <summary>
        /// Error page (Should be moved to shared location)
        /// </summary>
        /// <returns></returns>
        public IActionResult ErrorPage()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
