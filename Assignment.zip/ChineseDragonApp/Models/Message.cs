﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResturentApp.Models
{
    public class Message
    {
        public bool IsSuccess { get; set; }
        public string ReturnMessage { get; set; }
    }
}
