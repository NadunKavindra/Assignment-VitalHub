﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResturentApp.Models
{
    public class MySettingsModel
    {
        public string Baseurl { get; set; }
    }
}
