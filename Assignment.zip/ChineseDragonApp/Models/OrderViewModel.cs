﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ResturentApp.Models
{
    public class OrderViewModel
    {
        public int Id { get; set; }
        public string OrderReference { get; set; }
        public DateTime OrderDateTime { get; set; }
        public int OrderThrough { get; set; }
        public int OrderType { get; set; }
        public int OrderStatus { get; set; }
        public List<OrderMenuItemViewModel> OrderMenuItems { get; set; }
    }
}
