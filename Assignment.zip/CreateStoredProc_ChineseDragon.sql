USE [ChinaDragon]

-- ============================== Stored Proc ====================================


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Nadun Kavindra>
-- Create date: <Create Date,,2022-06-04>
-- Description: <Description,,Get all the menu item details>
-- EXEC GetMenuItems
-- =============================================
CREATE PROCEDURE [dbo].[GetMenuItems]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM MenuItem(NOLOCK) ORDER BY Int_Key ASC
END




SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Nadun Kavindra>
-- Create date: <Create Date,,2022-06-04>
-- Description: <Description,,Get all the orders details>
-- EXEC GetMenuItems
-- =============================================
CREATE PROCEDURE [dbo].[GetOrderDetails]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT * FROM CustomerOrders(NOLOCK) ORDER BY Int_Key ASC
END





SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Nadun Kavindra>
-- Create date: <Create Date,,2022-06-04>
-- Description: <Description,,Can define status based on ReturnCode>
-- =============================================
CREATE PROCEDURE [dbo].[CreateOrder]
(
@Id INT,
@OrderRef NVARCHAR(255),
@OrderThrough INT,
@OrderTyp INT,
@OrderStat INT,
@ReturnCode NVARCHAR(20) OUTPUT
)
AS
BEGIN
    SET @ReturnCode = 'C200'
    
	IF EXISTS (SELECT 1 FROM CustomerOrders WHERE OrderReference = @OrderRef)  
		BEGIN
			SET @ReturnCode = 'C201'
			RETURN
		END
	ELSE
		BEGIN
			INSERT INTO CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus)
			VALUES (@OrderRef,@OrderThrough,@OrderTyp,@OrderStat)
			SET @ReturnCode = 'C200'
		END
		
END




SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Nadun Kavindra>
-- Create date: <Create Date,,2022-06-04>
-- Description: <Description,,Update Order Status>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateOrderStatus]
(
@OrderRef NVARCHAR(255),
@OrderStatus INT,
@ReturnCode NVARCHAR(20) OUTPUT
)
AS
BEGIN
    SET @ReturnCode = 'U200'
    
	IF EXISTS (SELECT 1 FROM CustomerOrders WHERE OrderReference = @OrderRef)  
		BEGIN
			UPDATE CustomerOrders SET OrderStatus = @OrderStatus WHERE OrderReference = @OrderRef
			SET @ReturnCode = 'U200'
			RETURN
		END
	ELSE
		BEGIN			
			SET @ReturnCode = 'U201'
		END
		
END




SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author,,Nadun Kavindra>
-- Create date: <Create Date,,2022-06-04>
-- Description: <Description,,Get all the orders menu item details>
-- EXEC GetMenuItems
-- =============================================
CREATE PROCEDURE [dbo].[GetMenuItemsForOrder](
@OrderRef NVARCHAR(255)
)
AS
BEGIN
    SET NOCOUNT ON;    
	SELECT A.OrderReference,A.MenuItemCode, B.Description AS MenuItemDescription, B.Price, A.Quantity  
	FROM OrderMenuItems AS A
	INNER JOIN MenuItem AS B
	ON A.MenuItemCode = B.ItemCode
	WHERE A.OrderReference = @OrderRef
END