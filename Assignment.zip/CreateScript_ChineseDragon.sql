--CREATE DATABASE ChinaDragon;

USE [ChinaDragon]

CREATE TABLE MenuItem (
    Int_Key INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    ItemCode varchar(255) NOT NULL UNIQUE,
    Description varchar(max) DEFAULT '',
    PortionSize varchar(50),
    Price decimal(6,2)
);


CREATE TABLE CustomerOrders (
    Int_Key INT IDENTITY (100,1) NOT NULL PRIMARY KEY,
    OrderReference varchar(255) NOT NULL UNIQUE,
    OrderDateTime DATETIME DEFAULT GETDATE(),
    OrderThrough INT DEFAULT 0, -- 0-online / 1-pos
	OrderType INT DEFAULT 0, -- 0-dine in / 1-take away
	OrderStatus INT DEFAULT 1 -- 1-in queue /2 -Preparing / 3-Order ready / 4-picked up / 5-cancelled
);


CREATE TABLE OrderMenuItems (
    Int_Key INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
	OrderReference varchar(255) FOREIGN KEY REFERENCES CustomerOrders(OrderReference),
    MenuItemCode varchar(255) FOREIGN KEY REFERENCES MenuItem(ItemCode),
    Description varchar(max) DEFAULT '',
    Quantity INT NOT NULL DEFAULT 1
);




-- ####################### Data set for testing ###########################


Insert Into MenuItem values ('M001', 'Noodels', 'M', 850.00)
Insert Into MenuItem values ('M021', 'Chicken Rice', 'M', 1200.50)
Insert Into MenuItem values ('M540', 'Noodels Suope', 'M', 780.40)
Insert Into MenuItem values ('M112', 'Mushroom', 'M', 1800.70)
Insert Into MenuItem values ('M451', 'Beans', 'M', 550.00)
Insert Into MenuItem values ('M003', 'Sauces', 'M', 220.60)
Insert Into MenuItem values ('M005', 'Chees Pasta', 'M', 1200.30)
Insert Into MenuItem values ('M452', 'Beans', 'S', 250.00)
Insert Into MenuItem values ('M004', 'Sauces', 'S', 180.80)
Insert Into MenuItem values ('M006', 'Chees Pasta', 'S', 1500.80)
Insert Into MenuItem values ('M002', 'Noodels', 'L', 1690.20)
Insert Into MenuItem values ('M023', 'Chicken Rice', 'L', 2500.50)
Insert Into MenuItem values ('M541', 'Noodels Suope', 'L', 1600.40)



Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220514-AM0400',1,0,3)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220524-AM0400',1,1,1)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220604-AM0400',0,0,2)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('T20220516-AM0400',0,1,3)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220324-AM0400',1,1,4)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220556-AM0400',1,1,5)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220377-AM0400',1,1,5)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220965-AM0400',1,1,1)
Insert Into CustomerOrders(OrderReference,OrderThrough,OrderType,OrderStatus) values('D20220234-AM0400',1,1,1)



Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220514-AM0400','M001','Customer One', 1)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220514-AM0400','M452','Customer One', 2)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220377-AM0400','M001','Customer One', 3)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220377-AM0400','M006','Customer One', 1)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220377-AM0400','M541','Customer One', 4)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220965-AM0400','M003','Customer One', 1)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220965-AM0400','M112','Customer One', 2)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220234-AM0400','M006','Customer One', 2)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220234-AM0400','M452','Customer One', 2)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220524-AM0400','M001','Customer One', 4)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220524-AM0400','M003','Customer One', 1)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220604-AM0400','M452','Customer One', 1)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220604-AM0400','M001','Customer One', 3)
Insert into OrderMenuItems(OrderReference,MenuItemCode,Description,Quantity) values('D20220604-AM0400','M005','Customer One', 5)




